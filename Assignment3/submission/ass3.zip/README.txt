This assignment was done on Windows Subsystem for Linux (Ubuntu-like)
It is compatible on mimi.cs.mcgill.ca. I ran it there.

I tested all features. I believe I have resolved every bugs. 
It should be fully functional. I have submitted the same given testfile.txt
along with script1.txt script2.txt script3.txt as my program can run them.

I have attached compile.sh and also a makefile which is used to compile my .c files into an
executable called mykernel.

Thank you. Have a great day!

- Ridwan Kurmally