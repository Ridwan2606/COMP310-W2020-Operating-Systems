OS used: Ubuntu on mimi.cs.mcgill.ca

My program is hopefully functional. It works for every asked commands.
I submitted the same test file as the one provided.

Thank you. Have a good day!

- Ridwan

